package ru.startandroid.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void result0 (View v) {
        EditText edit = findViewById(R.id.editText);
        int val = Integer.valueOf(edit.getText().toString());
        String hex = Integer.toHexString(val);
        Toast.makeText (getApplicationContext(), hex, Toast.LENGTH_LONG).show();
    }
    public void result1 (View v) {
        EditText edit = findViewById(R.id.editText);
        int val = Integer.valueOf(edit.getText().toString());
        String oct = Integer.toOctalString(val);
        Toast.makeText(getApplicationContext(), oct, Toast.LENGTH_LONG).show();
    }
}
